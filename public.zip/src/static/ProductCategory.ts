export const productCategory = [
  { name: "Glasses", icon: "Glasses" },
  { name: "Glass", icon: "ScanEye" },
  { name: "Lenses", icon: "Eye" },
  { name: "Lenses Kit", icon: "BriefcaseBusiness" },
  { name: "Accessories", icon: "Boxes" },
  { name: "General", icon: "Component" },
];
