export const socialChannels = [
  {
    name: "Facebook",
    icon: "Facebook",
    desc: "Facebook",
  },
  {
    name: "Instagram",
    icon: "Instagram",
    desc: "Instagram",
  },
  {
    name: "Twitter/X",
    icon: "Twitter",
    desc: "Twitter",
  },
  {
    name: "Linkedin",
    icon: "Linkedin",
    desc: "Linkedin",
  },
  {
    name: "Youtube",
    icon: "Youtube",
    desc: "Youtube",
  },
];

export const facebookPostType = ["Post", "Reel", "Story"];
