export interface ProductCategoryCardProps {
  name: string;
  icon: string;
  active: boolean;
  onClick: () => void;
}
