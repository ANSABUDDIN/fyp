const Board = () => {
  return (
    <div>Board</div>
  )
}

export default Board